export const VietnameseText:any;
