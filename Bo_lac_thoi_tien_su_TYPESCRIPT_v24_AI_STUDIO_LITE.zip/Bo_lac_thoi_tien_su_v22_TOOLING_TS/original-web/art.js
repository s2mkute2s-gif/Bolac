import { renderHudIcon } from './hud-icons.js';
// High-resolution presentation assets. Java coordinates remain 240 × 320.
export const ART_SCALE = 3;
export function imageFingerprint(bytes) { let h = 2166136261; for (const b of bytes)
    h = Math.imul(h ^ b, 16777619); return (h >>> 0).toString(16); }
export class GameArt {
    images;
    manifest;
    replacements = 0;
    avatarDraws = 0;
    avatarIds;
    constructor(images, manifest, makeCanvas) { this.images = images; this.manifest = manifest; this.replacements = 0; if (makeCanvas) {
        this.buildTerrain(makeCanvas);
    } }
    buildTerrain(makeCanvas) { const source = this.images['terrain.webp']; if (!source)
        return; const out = makeCanvas(396, 288), ctx = out.getContext('2d'); for (let i = 0; i < 3; i++)
        ctx.drawImage(source, i * source.width / 3 + source.width / 3 * .3, source.height * .15, source.width / 3 * .4, source.height * .4, 132 * i, 0, 132, 288); this.images['terrain.webp'] = out; }
    replacement(bytes) { const entry = this.manifest.replacements[imageFingerprint(bytes)]; if (!entry)
        return null; this.replacements++; return { canvas: this.images[entry.file], width: entry.width, height: entry.height, hd: true }; }
    // The original resident record stores sex at byte 1515 + resident ID (0 male, 1 female).
    // Header 4 follows the list selection; header 12 follows the world selection.
    avatarSex(native, t) { const frame = t?.frames?.find((f) => f.owner === 'f' && f.method.name === 'a' && f.method.desc === '(BII)V' && [4, 12].includes(f.locals[1])); if (!frame)
        return null; const o = frame.locals[0], id = native.vm.get(o, 'f', frame.locals[1] === 4 ? 'l' : 'am', 'B'), data = native.vm.get(o, 'f', 'e', '[B'); if (!Number.isInteger(id) || id < 0 || !data)
        return null; const sex = data[1515 + id]; return sex === 0 || sex === 1 ? sex : null; }
    avatar(native, g, img, sx, sy, w, h, dx, dy, t) { const source = this.images['villager-avatars.webp']; if (!source || img.width !== 121 || img.height !== 151)
        return false; const sex = this.avatarSex(native, t); if (sex === null)
        return false; const originalColumn = Math.max(0, Math.min(3, Math.floor((sx + w / 2) / (121 / 4)))), originalRow = Math.max(0, Math.min(4, Math.floor((sy + h / 2) / (151 / 5)))), identity = originalRow * 4 + originalColumn, index = sex === 0 ? identity % 12 : 12 + identity % 8, column = index % 4, row = Math.floor(index / 4), cellW = source.width / 4, cellH = source.height / 5, cx = dx + w / 2, cy = dy + h / 2, r = Math.min(w, h) / 2; this.avatarDraws = (this.avatarDraws || 0) + 1; (this.avatarIds ??= new Set()).add(row * 4 + column); native.draw(g, (ctx) => { ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high'; ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.clip(); ctx.drawImage(source, column * cellW, row * cellH, cellW, cellH, cx - r, cy - r, 2 * r, 2 * r); ctx.restore(); ctx.strokeStyle = '#edd399'; ctx.lineWidth = .9; ctx.beginPath(); ctx.arc(cx, cy, r + .25, 0, Math.PI * 2); ctx.stroke(); }); return true; }
    panel(native, g, args, t) { const [x, y, w, h] = args; if (g.color !== '#c2b651')
        return false; const panels = g.detailPanels ??= new Map(); let box = [...panels.values()].find((b) => x >= b.x && y >= b.y && x + w <= b.x + b.w && y + h <= b.y + b.h); if (w === 240) {
        if (h !== 44 || !t.frames.some((f) => f.owner === 'f' && f.method.name === 'a' && f.method.desc === '(BII)V' && [4, 12].includes(f.locals[1]))) {
            panels.delete(y);
            return false;
        }
        box = { x, y, w, h: 48 };
        panels.set(y, box);
        native.draw(g, (ctx) => { const gradient = ctx.createLinearGradient(0, y, 0, y + 48); gradient.addColorStop(0, '#284338'); gradient.addColorStop(1, '#102820'); ctx.fillStyle = gradient; ctx.fillRect(x, y, w, 48); ctx.strokeStyle = '#d2af68'; ctx.lineWidth = .65; ctx.strokeRect(x + .5, y + .5, w - 1, 47); ctx.strokeStyle = '#c6ac6844'; ctx.beginPath(); ctx.moveTo(x + 86, y + 5); ctx.lineTo(x + 86, y + 39); ctx.moveTo(x + 139, y + 5); ctx.lineTo(x + 139, y + 39); ctx.stroke(); });
        return true;
    } if (box && x >= box.x && y >= box.y && x + w <= box.x + box.w && y + h <= box.y + box.h) {
        native.draw(g, (ctx) => { const gradient = ctx.createLinearGradient(0, box.y, 0, box.y + 48); gradient.addColorStop(0, '#284338'); gradient.addColorStop(1, '#102820'); ctx.fillStyle = gradient; ctx.fillRect(x, y, w, h); });
        return true;
    } return false; }
    region(native, g, img, sx, sy, w, h, transform, x, y, anchor, t) { const [dx, dy] = native.anchor(x, y, transform >= 4 ? h : w, transform >= 4 ? w : h, anchor), box = [...(g.detailPanels?.values() || [])].find((b) => dy >= b.y - 2 && dy <= b.y + b.h + 2); if (img.width === 102 && img.height === 71 && box && t.frames.some((f) => f.owner === 'f' && f.method.name === 'a' && f.method.desc === '(BII)V' && [4, 12].includes(f.locals[1])) && dy >= box.y - 2 && dy <= box.y + box.h + 2) {
        native.draw(g, (ctx) => { ctx.strokeStyle = '#d2af68'; ctx.lineWidth = .8; ctx.beginPath(); ctx.moveTo(Math.max(box.x, dx), box.y + box.h - .5); ctx.lineTo(Math.min(box.x + box.w, dx + w), box.y + box.h - .5); ctx.stroke(); });
        return true;
    } if (renderHudIcon(native, g, img, sx, sy, w, h, dx, dy, t))
        return true; if (this.avatar(native, g, img, sx, sy, w, h, dx, dy, t))
        return true; if ((img.width === 121 && img.height === 151) || (img.width === 114 && img.height === 62)) {
        img.hd = true;
        native.draw(g, (ctx) => { const r = Math.min(w, h) / 2 + 1, cx = dx + w / 2, cy = dy + h / 2; const gradient = ctx.createRadialGradient(cx - 3, cy - 4, 1, cx, cy, r); gradient.addColorStop(0, '#587759'); gradient.addColorStop(1, '#152b25'); ctx.fillStyle = gradient; ctx.strokeStyle = '#e0c078'; ctx.lineWidth = .9; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); });
    } return false; }
    mainMenu(native, g, o, slots) { if (!this.images['menu.webp'] || !slots.some((s) => s?.label === 57) || !slots.some((s) => s?.label === 58))
        return; const game = native.vm.get(o, 'c', 'a', 'Lf;'), selected = native.vm.get(game, 'f', 'Z', 'I'), clip = g.clip; g.clip = [0, 0, 264, 352]; native.draw(g, (ctx) => { ctx.imageSmoothingEnabled = true; ctx.drawImage(this.images['menu.webp'], 11, 8, 240, 320); const shade = ctx.createLinearGradient(0, 8, 0, 328); shade.addColorStop(0, '#092a24aa'); shade.addColorStop(.6, '#0d211329'); shade.addColorStop(1, '#091e1766'); ctx.fillStyle = shade; ctx.fillRect(11, 8, 240, 320); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic'; ctx.font = 'bold 22px TribesVN'; ctx.strokeStyle = '#172b20'; ctx.lineWidth = 3; ctx.fillStyle = '#ffe4a0'; ctx.strokeText('BỘ LẠC', 131, 43); ctx.fillText('BỘ LẠC', 131, 43); ctx.font = 'bold 12px TribesVN'; ctx.fillText('THỜI TIỀN SỬ', 131, 61); ctx.fillStyle = '#102d26df'; ctx.strokeStyle = '#dfba6b'; ctx.lineWidth = .8; ctx.beginPath(); ctx.roundRect(38, 80, 186, 119, 9); ctx.fill(); ctx.stroke(); const items = slots.filter((s) => [57, 58, 59, 60, 62].includes(s?.label)); const pick = items[Math.max(0, Math.min(items.length - 1, selected))]; if (pick) {
        const slot = slots.indexOf(pick), y = native.vm.get(o, 'c', 'e', '[S')[slot] + 8;
        ctx.fillStyle = '#f5d07930';
        ctx.beginPath();
        ctx.roundRect(43, y - 2, 176, 18, 4);
        ctx.fill();
        ctx.fillStyle = '#ffe4a0';
        ctx.font = '10px TribesVN'; /* Original selection arrows are drawn by the Java UI. */
    } ctx.font = '9px TribesVN'; ctx.fillStyle = '#ffefbd'; ctx.textAlign = 'left'; ctx.fillText('Chọn', 37, 315); ctx.textAlign = 'right'; ctx.fillText('Quay lại', 222, 315); }); g.clip = clip; }
}
//# sourceMappingURL=art.js.map