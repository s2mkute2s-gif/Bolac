import { TouchControls, bindTouch } from './touch.js';
import { GameArt, ART_SCALE } from './art.js';
import { VietnameseText } from './unicode-text.js';
import { VM } from './vm.js';
import { MIDP } from './midp.js';
import { MidiAudio } from './midi.js';
const $ = (id) => document.getElementById(id), canvas = $('game'), audio = new MidiAudio(), held = new Set();
let vm, midp, touch, paused = false, modalPrevious = false, virtualTime = Date.now(), last = performance.now(), ready = false, lastError = null;
const makeCanvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
function status(msg) { $('status').textContent = msg; }
function fail(e) { lastError = e; paused = true; $('loading').hidden = false; $('loading').querySelector('strong').textContent = 'Chưa thể chạy tiếp'; $('loadingText').textContent = e instanceof Error ? e.message : String(e); $('retry').hidden = false; console.error(e); status('Lỗi tương thích — tiến trình đã lưu vẫn được giữ lại'); }
function key(code, on) { if (!ready || paused || $('menu').open)
    return; if (on) {
    if (held.has(code))
        return;
    held.add(code);
    audio.unlock();
}
else {
    if (!held.has(code))
        return;
    held.delete(code);
} ; midp.key(code, on); document.querySelectorAll(`[data-key="${code}"]`).forEach(b => b.classList.toggle('pressed', on)); }
function release() { touch?.cancel(); for (const k of held) {
    midp?.key(k, false);
} held.clear(); document.querySelectorAll('.pressed').forEach(b => b.classList.remove('pressed')); }
function setPause(value) { release(); paused = value; audio.pause(value); $('paused').hidden = !value || !ready; $('pause').textContent = value ? '▶' : 'Ⅱ'; last = performance.now(); }
function showDialog(title, html) { release(); if (!$('menu').open)
    modalPrevious = paused; setPause(true); $('menu').querySelector('h2').textContent = title; $('dialogContent').innerHTML = html; if (!$('menu').open)
    $('menu').showModal(); }
function closeDialog() { $('menu').close(); setPause(modalPrevious); }
function showHelp() { showDialog('Điều khiển cảm ứng', `<p><b>Chạm dân làng hoặc công trình</b> để chọn. Chọn dân làng rồi chạm vị trí hoặc tài nguyên để ra lệnh theo game.</p><p><b>Vuốt bản đồ</b> để di chuyển góc nhìn. Chạm mục trong menu để chọn; vuốt ngang dãy biểu tượng để xem thêm, vuốt dọc để cuộn nội dung.</p><p><b>Chọn nhóm:</b> nhấn giữ trên bản đồ đến khi khung chọn xuất hiện, rồi kéo bao quanh dân làng và thả tay. Chạm ô nhóm 7/9 ở thanh dưới để gọi nhóm, nhấn giữ để gán nhóm. Chạm biểu tượng bản đồ ở thanh dưới để mở bản đồ nhỏ.</p><p>Chạm <b>hai góc dưới màn hình game</b> để xác nhận, mở menu hoặc quay lại theo biểu tượng đang hiện. Chạm thanh thông tin phía trên để xem chi tiết.</p><p><b>Lưu game:</b> mở menu trong game ở góc dưới bên phải, chọn <b>Lưu lại</b>. Dữ liệu lưu vẫn ở trên thiết bị này.</p><p>Trên máy tính, bạn cũng có thể dùng chuột hoặc bàn phím: mũi tên, Enter, Q và Escape.</p>`); }
function menu() { showDialog('Tùy chọn', `<button class="wide" id="resume">Tiếp tục</button><button class="wide" id="instructions">Cách điều khiển và lưu game</button><button class="wide" id="exportSave">Xuất dữ liệu lưu gốc</button><button class="wide" id="importSave">Nhập dữ liệu lưu gốc</button><button class="wide" id="reloadGame">Khởi động lại game</button><p>Nhạc dùng các nốt và nhịp MIDI gốc; âm sắc tổng hợp trên trình duyệt có thể khác điện thoại Java.</p><p class="warning">Hãy lưu bằng menu trong game trước khi đóng trang hoặc khởi động lại.</p>`); $('resume').onclick = closeDialog; $('instructions').onclick = showHelp; $('exportSave').onclick = () => { const records = {}; for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k.startsWith('tribes-original-rms:'))
        records[k] = JSON.parse(localStorage.getItem(k));
} const blob = new Blob([JSON.stringify({ format: 'tribes-original-rms-v1', records })], { type: 'application/json' }), a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'bo-lac-ban-luu-goc.json'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000); status('Đã xuất dữ liệu lưu gốc'); }; $('importSave').onclick = () => { const input = document.createElement('input'); input.type = 'file'; input.accept = '.json'; input.onchange = async () => { try {
    if (input.files[0].size > 10000000)
        throw Error('Bản lưu quá lớn');
    const data = JSON.parse(await input.files[0].text());
    if (data.format !== 'tribes-original-rms-v1' || !data.records || typeof data.records !== 'object' || Array.isArray(data.records))
        throw Error('Không đúng định dạng bản lưu gốc');
    for (const [k, v] of Object.entries(data.records)) {
        if (!/^tribes-original-rms:[a-zA-Z0-9_-]{1,64}$/.test(k) || !Array.isArray(v) || v.length > 30 || !v.every(r => Array.isArray(r) && r.length < 2000000 && r.every(b => Number.isInteger(b) && b >= -128 && b <= 255)))
            throw Error('Dữ liệu lưu không hợp lệ');
    }
    showDialog('Thay dữ liệu lưu?', `<p>Bản lưu trên thiết bị này sẽ được thay bằng tệp vừa chọn. Game sẽ khởi động lại.</p><button class="wide" id="confirmImport">Nhập và khởi động lại</button><button class="wide" id="cancelImport">Hủy</button>`);
    $('cancelImport').onclick = menu;
    $('confirmImport').onclick = () => { const keys = []; for (let i = 0; i < localStorage.length; i++)
        if (localStorage.key(i).startsWith('tribes-original-rms:'))
            keys.push(localStorage.key(i)); for (const k of keys)
        localStorage.removeItem(k); for (const [k, v] of Object.entries(data.records))
        localStorage.setItem(k, JSON.stringify(v)); location.reload(); };
}
catch (e) {
    status(e instanceof Error ? e.message : String(e));
} }; input.click(); }; $('reloadGame').onclick = () => { showDialog('Khởi động lại?', `<p>Tiến trình chưa lưu trong game sẽ mất. Dữ liệu đã lưu vẫn được giữ.</p><button class="wide" id="confirmReload">Khởi động lại</button><button class="wide" id="cancelReload">Hủy</button>`); $('confirmReload').onclick = () => location.reload(); $('cancelReload').onclick = menu; }; }
async function boot() {
    try {
        const load = async (p) => { const r = await fetch(p); if (!r.ok)
            throw Error('Không tải được ' + p); return r; };
        const font = await new FontFace('TribesVN', 'url(./fonts/TribesVN.ttf)').load();
        document.fonts.add(font);
        const [classes, names, locale] = await Promise.all([load('classes.json').then(r => r.json()), load('resources.json').then(r => r.json()), load('locale/vi.json').then(r => r.json())]);
        const resources = {};
        let done = 0;
        await Promise.all(names.map(async (name) => { resources[name] = new Uint8Array(await load('resources/' + name.split('/').map(encodeURIComponent).join('/')).then(r => r.arrayBuffer())); $('progress').value = ++done / names.length * 100; }));
        const manifest = Object.fromEntries(new TextDecoder().decode(resources['META-INF/MANIFEST.MF']).split(/\r?\n/).filter(x => x.includes(': ')).map(x => [x.slice(0, x.indexOf(': ')), x.slice(x.indexOf(': ') + 2)]));
        const artManifest = await load('art/manifest.json').then(r => r.json()), artImages = {};
        await Promise.all(artManifest.files.map(async (name) => { artImages[name] = await createImageBitmap(await load('art/' + name).then(r => r.blob())); }));
        const art = new GameArt(artImages, artManifest, makeCanvas);
        canvas.width = 240 * ART_SCALE;
        canvas.height = 320 * ART_SCALE;
        canvas.renderScale = ART_SCALE;
        const storage = { getItem: (k) => { try {
                return localStorage.getItem(k);
            }
            catch {
                return null;
            } }, setItem: (k, v) => localStorage.setItem(k, v), removeItem: (k) => localStorage.removeItem(k) };
        midp = new (MIDP)({ renderScale: ART_SCALE, art, canvas, makeCanvas, decodeImage: (bytes) => createImageBitmap(new Blob([bytes], { type: 'image/png' })), resources, manifest, storage, clock: () => virtualTime, onError: fail, onStatus: status, audio });
        midp.textBridge = new VietnameseText(midp, locale);
        vm = new VM(classes, midp);
        touch = new TouchControls(midp, { key, feedback: (x, y) => { const ring = $('touchRing'); ring.style.left = (x / 240 * 100) + '%'; ring.style.top = (y / 320 * 100) + '%'; ring.classList.remove('active'); void ring.offsetWidth; ring.classList.add('active'); } });
        bindTouch(canvas, touch, { enabled: () => ready && !paused && !$('menu').open, onInteract: () => audio.unlock() });
        audio.onEnd = (p) => { if (p.listener && vm.resolve(p.listener.javaClass, 'playerUpdate', '(Ljavax/microedition/media/Player;Ljava/lang/String;Ljava/lang/Object;)V').method)
            vm.start(p.listener, 'playerUpdate', '(Ljavax/microedition/media/Player;Ljava/lang/String;Ljava/lang/Object;)V', [p, 'endOfMedia', null]); };
        const app = vm.newObject('tribes');
        vm.start(app, '<init>', '()V');
        vm.tick(virtualTime, 10000);
        vm.start(app, 'startApp', '()V');
        ready = true;
        $('loading').hidden = true;
        status('Chạm để chọn · Vuốt để di chuyển bản đồ');
        last = performance.now();
        requestAnimationFrame(frame);
    }
    catch (e) {
        fail(e);
    }
}
function frame(now) { const dt = Math.min(50, now - last); last = now; if (!paused && !document.hidden && ready) {
    virtualTime += dt;
    touch?.tick(virtualTime);
    vm.tick(virtualTime, 120000, 8);
    midp.render(virtualTime, 4);
    audio.tick(dt / 1000);
} requestAnimationFrame(frame); }
document.querySelectorAll('[data-key]').forEach((b) => { const code = Number(b.dataset.key); b.onpointerdown = (e) => { e.preventDefault(); b.setPointerCapture(e.pointerId); key(code, true); }; b.onpointerup = (e) => { e.preventDefault(); key(code, false); }; b.onpointercancel = () => key(code, false); b.onlostpointercapture = () => key(code, false); b.oncontextmenu = (e) => e.preventDefault(); });
const mapKey = (e) => ({ ArrowUp: 50, ArrowDown: 56, ArrowLeft: 52, ArrowRight: 54, Enter: 53, ' ': 53, q: -6, Q: -6, e: -7, E: -7, Escape: -7, '*': 42, '#': 35 })[e.key] ?? (/^\d$/.test(e.key) ? e.key.charCodeAt(0) : null);
document.addEventListener('keydown', e => { if ($('menu').open)
    return; const code = mapKey(e); if (code !== null) {
    e.preventDefault();
    if (!e.repeat)
        key(code, true);
} });
document.addEventListener('keyup', e => { const code = mapKey(e); if (code !== null) {
    e.preventDefault();
    key(code, false);
} });
window.addEventListener('blur', release);
document.addEventListener('visibilitychange', () => { release(); last = performance.now(); audio.pause(document.hidden || paused); });
$('pause').onclick = () => setPause(!paused);
$('fullscreen').onclick = async () => { try {
    if (document.fullscreenElement)
        await document.exitFullscreen();
    else
        await document.documentElement.requestFullscreen();
}
catch {
    status('Trình duyệt này không hỗ trợ toàn màn hình');
} };
$('menuButton').onclick = menu;
$('closeMenu').onclick = closeDialog;
$('menu').addEventListener('cancel', (e) => { e.preventDefault(); closeDialog(); });
$('help').onclick = showHelp;
$('retry').onclick = () => location.reload();
$('sound').onclick = () => { audio.muted = !audio.muted; if (audio.muted)
    for (const p of audio.players.values())
        for (const n of p.notes.values())
            audio.release(n);
else
    audio.unlock(); $('sound').textContent = 'Âm thanh: ' + (audio.muted ? 'tắt' : 'bật'); };
canvas.addEventListener('pointerdown', () => { audio.unlock(); canvas.focus(); });
window.addEventListener('beforeunload', e => { if (ready) {
    e.preventDefault();
    e.returnValue = '';
} });
if (document.modelContext?.registerTool) {
    try {
        document.modelContext.registerTool({ name: 'read_original_game_status', description: 'Đọc trạng thái trình chạy mã Java gốc.', inputSchema: { type: 'object', properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true }, execute: () => ({ ready, paused, error: lastError?.message || null, currentScreen: midp?.current?.javaClass || null, instructions: vm?.count || 0 }) });
        document.modelContext.registerTool({ name: 'press_original_game_key', description: 'Bấm một phím trong game gốc; có thể chọn mục, di chuyển hoặc xác nhận hành động trong game.', inputSchema: { type: 'object', properties: { key: { type: 'integer', enum: [-6, -7, 42, 35, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57] } }, required: ['key'], additionalProperties: false }, execute: async (input) => { if (![-6, -7, 42, 35, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57].includes(input.key))
                throw Error('Phím không hợp lệ'); if (!ready || paused || $('menu').open)
                throw Error('Game chưa sẵn sàng hoặc đang tạm dừng'); key(input.key, true); await new Promise(r => setTimeout(r, 130)); key(input.key, false); return { pressed: input.key }; } });
    }
    catch { }
}
if ('serviceWorker' in navigator)
    navigator.serviceWorker.register('./sw.js').catch(() => { });
boot();
//# sourceMappingURL=shell.js.map