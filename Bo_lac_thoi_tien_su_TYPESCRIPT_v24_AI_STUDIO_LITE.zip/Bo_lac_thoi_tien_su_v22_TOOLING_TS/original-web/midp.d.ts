export const MIDP:any;
